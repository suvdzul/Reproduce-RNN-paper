# mimic-analysis-template

A template for conducting an analysis in the MIMIC clinical databases

## Quickstart

1. Create a GCP project
2. GCS, BigQuery, etc..
3. Create the tables
4. Export the tables
5. Install Python environment
6. Load into the notebook, run notebook